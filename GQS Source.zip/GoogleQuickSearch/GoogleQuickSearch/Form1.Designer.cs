﻿namespace GoogleQuickSearch
{
    partial class Main
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.Icon = new System.Windows.Forms.NotifyIcon(this.components);
            this.IconMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.dockUndockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hideToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SearchBox = new System.Windows.Forms.TextBox();
            this.SettingsButton = new System.Windows.Forms.PictureBox();
            this.UrlButton = new System.Windows.Forms.PictureBox();
            this.IncognitoButton = new System.Windows.Forms.PictureBox();
            this.SearchButton = new System.Windows.Forms.PictureBox();
            this.ClearButton = new System.Windows.Forms.PictureBox();
            this.IconMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SettingsButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UrlButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IncognitoButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SearchButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClearButton)).BeginInit();
            this.SuspendLayout();
            // 
            // Icon
            // 
            this.Icon.ContextMenuStrip = this.IconMenu;
            this.Icon.Icon = ((System.Drawing.Icon)(resources.GetObject("Icon.Icon")));
            this.Icon.Text = "Quick Search";
            this.Icon.Visible = true;
            this.Icon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Icon_MouseDoubleClick);
            // 
            // IconMenu
            // 
            this.IconMenu.BackColor = System.Drawing.SystemColors.Control;
            this.IconMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dockUndockToolStripMenuItem,
            this.exitToolStripMenuItem,
            this.hideToolStripMenuItem});
            this.IconMenu.Name = "IconMenu";
            this.IconMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.IconMenu.Size = new System.Drawing.Size(102, 70);
            // 
            // dockUndockToolStripMenuItem
            // 
            this.dockUndockToolStripMenuItem.Name = "dockUndockToolStripMenuItem";
            this.dockUndockToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.dockUndockToolStripMenuItem.Text = "Dock";
            this.dockUndockToolStripMenuItem.Click += new System.EventHandler(this.DockUndockToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click);
            // 
            // hideToolStripMenuItem
            // 
            this.hideToolStripMenuItem.Name = "hideToolStripMenuItem";
            this.hideToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.hideToolStripMenuItem.Text = "Hide";
            this.hideToolStripMenuItem.Click += new System.EventHandler(this.HideToolStripMenuItem_Click);
            // 
            // SearchBox
            // 
            this.SearchBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SearchBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.SearchBox.Location = new System.Drawing.Point(8, 6);
            this.SearchBox.Name = "SearchBox";
            this.SearchBox.Size = new System.Drawing.Size(218, 26);
            this.SearchBox.TabIndex = 1;
            this.SearchBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyPress);
            // 
            // SettingsButton
            // 
            this.SettingsButton.BackColor = System.Drawing.Color.Transparent;
            this.SettingsButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.SettingsButton.ImageLocation = "bin\\Icons\\SetBlack.png";
            this.SettingsButton.Location = new System.Drawing.Point(364, 5);
            this.SettingsButton.Name = "SettingsButton";
            this.SettingsButton.Size = new System.Drawing.Size(27, 27);
            this.SettingsButton.TabIndex = 9;
            this.SettingsButton.TabStop = false;
            this.SettingsButton.Click += new System.EventHandler(this.SettingsButton_Click);
            // 
            // UrlButton
            // 
            this.UrlButton.BackColor = System.Drawing.Color.Transparent;
            this.UrlButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.UrlButton.ImageLocation = "bin\\Icons\\UrlBlack.png";
            this.UrlButton.Location = new System.Drawing.Point(298, 5);
            this.UrlButton.Name = "UrlButton";
            this.UrlButton.Size = new System.Drawing.Size(27, 27);
            this.UrlButton.TabIndex = 10;
            this.UrlButton.TabStop = false;
            this.UrlButton.Click += new System.EventHandler(this.UrlButton_Click);
            // 
            // IncognitoButton
            // 
            this.IncognitoButton.BackColor = System.Drawing.Color.Transparent;
            this.IncognitoButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.IncognitoButton.ImageLocation = "bin\\Icons\\IncBlack.png";
            this.IncognitoButton.Location = new System.Drawing.Point(331, 5);
            this.IncognitoButton.Name = "IncognitoButton";
            this.IncognitoButton.Size = new System.Drawing.Size(27, 27);
            this.IncognitoButton.TabIndex = 11;
            this.IncognitoButton.TabStop = false;
            this.IncognitoButton.Click += new System.EventHandler(this.IncognitoButton_Click);
            // 
            // SearchButton
            // 
            this.SearchButton.BackColor = System.Drawing.Color.Transparent;
            this.SearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.SearchButton.ImageLocation = "bin\\Icons\\SrcBlack.png";
            this.SearchButton.Location = new System.Drawing.Point(232, 5);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(27, 27);
            this.SearchButton.TabIndex = 12;
            this.SearchButton.TabStop = false;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.BackColor = System.Drawing.Color.Transparent;
            this.ClearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClearButton.ImageLocation = "bin\\Icons\\ClrBlack.png";
            this.ClearButton.Location = new System.Drawing.Point(265, 5);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(27, 27);
            this.ClearButton.TabIndex = 13;
            this.ClearButton.TabStop = false;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(396, 37);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.IncognitoButton);
            this.Controls.Add(this.UrlButton);
            this.Controls.Add(this.SettingsButton);
            this.Controls.Add(this.SearchBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Main";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Google Quick Search";
            this.TopMost = true;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyPress);
            this.IconMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SettingsButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UrlButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IncognitoButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SearchButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClearButton)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.NotifyIcon Icon;
        private System.Windows.Forms.ContextMenuStrip IconMenu;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dockUndockToolStripMenuItem;
        private System.Windows.Forms.TextBox SearchBox;
        private System.Windows.Forms.PictureBox UrlButton;
        private System.Windows.Forms.PictureBox IncognitoButton;
        private System.Windows.Forms.PictureBox SearchButton;
        private System.Windows.Forms.PictureBox ClearButton;
        private System.Windows.Forms.ToolStripMenuItem hideToolStripMenuItem;
        protected System.Windows.Forms.PictureBox SettingsButton;
    }
}

