﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Globalization;

namespace GoogleQuickSearch
{
    public partial class Main : Form
    {
        private bool issettingsopen = false;
        private bool isincognito;
        private bool isurl;
        private string img = @"Icons\";
        private string imgex = ".png";
        private string icon = "Black";
        private string shshort = " (CTRL + M)";

        public Main()
        {
            InitializeComponent();

            dockUndockToolStripMenuItem.Text = "Dock";
            FormBorderStyle = FormBorderStyle.FixedSingle;
            SearchBox.Text = Properties.Settings.Default.LastText;

           #region File Check
            /*try 
            {
                #region App.bin
                if (!File.Exists("App.bin"))
                {
                    File.Create("App.bin").Close();
                    File.WriteAllText("App.bin", Properties.Settings.Default.Version);
                }
                else
                {
                    File.WriteAllText("App.bin", Properties.Settings.Default.Version);
                }
                #endregion
            }
            #region Exceptions
            catch (Exception)
            {
                MessageBox.Show("An error occured.");
            }
            #endregion*/
            #endregion

            hideToolStripMenuItem.Text = "Hide" + shshort;
            Theme();
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void DockUndockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Rectangle rec = RectangleToScreen(ClientRectangle);
            int topheight = rec.Top - Top;
            if (dockUndockToolStripMenuItem.Text == "Dock")
            {
                FormBorderStyle = FormBorderStyle.None;
                Location = new Point(Location.X + 8, Location.Y + topheight);
                dockUndockToolStripMenuItem.Text = "Undock";
            }
            else if (dockUndockToolStripMenuItem.Text == "Undock")
            {
                Location = new Point(Location.X - 8, Location.Y);
                FormBorderStyle = FormBorderStyle.FixedSingle;
                dockUndockToolStripMenuItem.Text = "Dock";
            }
                
        }

        private void KeyPress(object sender, KeyEventArgs k)
        {
            if (k.KeyCode.Equals(Keys.Return))
            {
                k.Handled = k.SuppressKeyPress = true;
                Search(SearchBox.Text, isincognito, isurl);
            }
            if (k.Control && k.KeyCode == Keys.M)
            {
                if (hideToolStripMenuItem.Text.Contains("Hide"))
                {
                    hideToolStripMenuItem.Text = "Show";
                    Hide();
                }
                else
                {
                    hideToolStripMenuItem.Text = "Hide" + shshort;
                    Show();
                }
            }
        }

        private void Icon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Show();
            BringToFront();
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            Search(SearchBox.Text, isincognito, isurl);
        }
        private void ClearButton_Click(object sender, EventArgs e)
        {
            SearchBox.Clear();
        }

        private void UrlButton_Click(object sender, EventArgs e)
        {
            #region Toggle Url
            if (isurl)
            {
                isurl = false;
                UrlButton.ImageLocation = img + "Url" + icon + imgex;
            }
            else
            {
                isurl = true;
                UrlButton.ImageLocation = img + "Url" + icon + "B" + imgex;
            }
            #endregion
        }

        private void IncognitoButton_Click(object sender, EventArgs e)
        {
            #region Toggle Incognito
            if (isincognito)
            {
                isincognito = false;
                IncognitoButton.ImageLocation = img + "Inc" + icon + imgex;
            }
            else
            {
                isincognito = true;
                IncognitoButton.ImageLocation = img + "Inc" + icon + "B" + imgex;
            }
            #endregion
        }

        private void SettingsButton_Click(object sender, EventArgs e)
        {
            #region Settings
            if (!issettingsopen)
            {
                Settings set = new Settings();
                set.MouseMove += new MouseEventHandler(settingssave);
                set.FormClosed += new FormClosedEventHandler(settingsclose);
                issettingsopen = true;
                set.Show();
            }
            #endregion
            return;
            #region old theme
            DialogResult d = MessageBox.Show("Choose theme\n\nAbort: White\nRetry: Black\nIgnore: Custom", "Settings", MessageBoxButtons.AbortRetryIgnore);
            if (d == DialogResult.Abort)
            {
                Theme("white");
            }
            else if (d == DialogResult.Retry)
            {
                Theme("black");
            }
            else if (d == DialogResult.Ignore)
            {
                Theme("custom");
            }
            #endregion
        }
        private void settingssave(object sender, MouseEventArgs e)
        {
            Theme();
        }
        private void settingsclose(object sender, FormClosedEventArgs e)
        {
            issettingsopen = false;
        }
        private void Search(string input, bool incognito, bool url)
        {
            #region Search
            try
            {
                if (incognito)
                {
                    if (url)
                    {
                        input = input.Replace(' ', '+');
                        if (input.Contains("http://") || input.Contains("https://"))
                        {
                            Process.Start(@"chrome.exe", "--incognito" + input);
                        }
                        else
                        {
                            Process.Start(@"chrome.exe", "--incognito http://" + input);
                        }

                    }
                    else
                    {
                        Process.Start(@"chrome.exe", "--incognito https://www.google.com/search?q=" + input + "&oq=a&aqs=chrome..69i57j69i60l3j69i65l2.2576j0j4&sourceid=chrome&ie=UTF-8");
                    }
                }
                else
                {
                    if (url)
                    {
                        input = input.Replace(' ', '+');
                        if (input.Contains("http://") || input.Contains("https://"))
                        {
                            Process.Start(@"chrome.exe", input);
                        }
                        else
                        {
                            Process.Start(@"chrome.exe", "http://" + input);
                        }

                    }
                    else
                    {
                        Process.Start(@"chrome.exe", "https://www.google.com/search?q=" + input + "&oq=a&aqs=chrome..69i57j69i60l3j69i65l2.2576j0j4&sourceid=chrome&ie=UTF-8");
                    }
                }
            }
            #region Exceptions
            catch (Exception ex)
            {
                MessageBox.Show("An error occured.\n\nPlease check errorlog.txt for more info", "Quick Search", MessageBoxButtons.OK, MessageBoxIcon.Error);
                File.Create(@"errorlog.txt").Close();
                File.WriteAllText(@"errorlog.txt", ex.ToString());
            }
            #endregion
            #endregion
        }

        public void Theme(string theme = "")
        {
            if (theme == "") { theme = Properties.Settings.Default.Theme; }
            #region Theme
            if (theme == "custom")
            {
                BackgroundImage = Image.FromFile(img + "Background" + imgex);
                icon = "White";
            }
            else
            {
                BackgroundImage = null;
            }

            try
            {
                Properties.Settings.Default.Theme = theme;
                Properties.Settings.Default.Save();
            }
            catch (Exception ex)
            {
                err(ex.ToString(), 1);
            }

            if (theme == "black")
            {
                BackColor = Color.FromArgb(0, 0, 0);
                SearchBox.BackColor = BackColor;
                SearchBox.ForeColor = Color.FromArgb(255, 255, 255);
                //this.TransparencyKey = Color.Black;
                //this.BackColor = Color.Black;
                icon = "White";
            }
            else if (theme == "white")
            {
                BackColor = Color.FromArgb(255, 255, 255);
                SearchBox.BackColor = BackColor;
                SearchBox.ForeColor = Color.FromArgb(0, 0, 0);
                icon = "Black";
                //this.TransparencyKey = Color.White;
                //this.BackColor = Color.White;
            }
                
            #endregion

            #region iconload
            SearchButton.ImageLocation = img + "Src" + icon + imgex;
            ClearButton.ImageLocation = img + "Clr" + icon + imgex;
            if (!isincognito) { IncognitoButton.ImageLocation = img + "Inc" + icon + imgex; } else { IncognitoButton.ImageLocation = img + "Inc" + icon + "B" + imgex; }
            if (!isurl) { UrlButton.ImageLocation = img + "Url" + icon + imgex; } else { UrlButton.ImageLocation = img + "Url" + icon + "B" + imgex; }           
            SettingsButton.ImageLocation = img + "Set" + icon + imgex;
            #endregion
            Refresh();
        }

        private void HideToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (hideToolStripMenuItem.Text.Contains("Hide"))
            {
                hideToolStripMenuItem.Text = "Show";
                Hide();
            }
            else
            {
                hideToolStripMenuItem.Text = "Hide" + shshort;
                Show();
            }
        }
        public void err(string err, int errtype = 0)
        {
            if (errtype == 0)
            {
                MessageBox.Show("An error occured.\n\n" + err, "Quick Search", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (errtype == 1)
            {
                MessageBox.Show("An error occured.\n\nPlease check errorlog.txt for more info", "Quick Search", MessageBoxButtons.OK, MessageBoxIcon.Error);
                File.Create(@"errorlog.txt").Close();
                File.WriteAllText(@"errorlog.txt", err.ToString());
            }
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            Icon.Visible = false;
            Properties.Settings.Default.LastText = SearchBox.Text;
            Properties.Settings.Default.Save();
        }
    }
}
