﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoogleQuickSearch
{
    public partial class Settings : Form
    {
        Main Main = new Main();
        public Settings()
        {
            InitializeComponent();
            Set();
        }

        private void Set()
        {
            BackColor = Main.BackColor;
            BackgroundImage = Main.BackgroundImage;
            panel3.BackgroundImage = Image.FromFile("Icons\\Background.png");
            Main.Theme();
        }

        private void LightTheme_Click(object sender, EventArgs e)
        {
            Main.Theme("white");
            Set();
        }

        private void DarkTheme_Click(object sender, EventArgs e)
        {
            Main.Theme("black");
            Set();
        }

        private void CustomTheme_Click(object sender, EventArgs e)
        {
            Main.Theme("custom");
            Set();
        }
    }
}
