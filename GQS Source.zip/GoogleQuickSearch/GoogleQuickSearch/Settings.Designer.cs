﻿namespace GoogleQuickSearch
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LightTheme = new System.Windows.Forms.Button();
            this.DarkTheme = new System.Windows.Forms.Button();
            this.CustomTheme = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // LightTheme
            // 
            this.LightTheme.BackColor = System.Drawing.Color.Gray;
            this.LightTheme.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.LightTheme.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LightTheme.ForeColor = System.Drawing.Color.White;
            this.LightTheme.Location = new System.Drawing.Point(12, 12);
            this.LightTheme.Name = "LightTheme";
            this.LightTheme.Size = new System.Drawing.Size(54, 23);
            this.LightTheme.TabIndex = 1;
            this.LightTheme.Text = "Light";
            this.LightTheme.UseVisualStyleBackColor = false;
            this.LightTheme.Click += new System.EventHandler(this.LightTheme_Click);
            // 
            // DarkTheme
            // 
            this.DarkTheme.BackColor = System.Drawing.Color.Gray;
            this.DarkTheme.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.DarkTheme.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DarkTheme.ForeColor = System.Drawing.Color.White;
            this.DarkTheme.Location = new System.Drawing.Point(12, 50);
            this.DarkTheme.Name = "DarkTheme";
            this.DarkTheme.Size = new System.Drawing.Size(54, 23);
            this.DarkTheme.TabIndex = 2;
            this.DarkTheme.Text = "Dark";
            this.DarkTheme.UseVisualStyleBackColor = false;
            this.DarkTheme.Click += new System.EventHandler(this.DarkTheme_Click);
            // 
            // CustomTheme
            // 
            this.CustomTheme.BackColor = System.Drawing.Color.Gray;
            this.CustomTheme.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.CustomTheme.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CustomTheme.ForeColor = System.Drawing.Color.White;
            this.CustomTheme.Location = new System.Drawing.Point(12, 91);
            this.CustomTheme.Name = "CustomTheme";
            this.CustomTheme.Size = new System.Drawing.Size(54, 23);
            this.CustomTheme.TabIndex = 3;
            this.CustomTheme.Text = "Custom";
            this.CustomTheme.UseVisualStyleBackColor = false;
            this.CustomTheme.Click += new System.EventHandler(this.CustomTheme_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(72, 10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(25, 25);
            this.panel1.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(72, 48);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(25, 25);
            this.panel2.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Location = new System.Drawing.Point(72, 89);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(25, 25);
            this.panel3.TabIndex = 6;
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(104, 127);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.CustomTheme);
            this.Controls.Add(this.DarkTheme);
            this.Controls.Add(this.LightTheme);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Settings";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Settings";
            this.TopMost = true;
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button LightTheme;
        private System.Windows.Forms.Button DarkTheme;
        private System.Windows.Forms.Button CustomTheme;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
    }
}